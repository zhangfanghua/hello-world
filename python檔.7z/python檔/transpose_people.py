from selenium import webdriver#selenium 為爬蟲的核心 用來啟動瀏覽器
from selenium.webdriver.common.keys import Keys #模擬鍵盤輸入的插件
from bs4 import BeautifulSoup#使用BeautifulSoup來解析網頁
from time import sleep #sleep為讓程式停止的意思 通常都是用在點擊後網頁會lag 就讓程式先停止稍後在做
import time, datetime #時間的插件
import numpy as np#資料的事前處理，多重維度的陣列
import pandas as pd#資料的事前處理，如資料補值，空值去除或取代等
import csv #為處理CSV的插件
import pymysql
from sqlalchemy import create_engine
import os #處理像是 檔案重新命名、移動、刪除......

options = webdriver.ChromeOptions()
options.add_argument("--disable-notifications")
options.add_experimental_option('useAutomationExtension', False)
chromedriver = r"\\vm02mfg\e$\VM02M0\資訊共享\Chromedriver\V100\chromedriver.exe"
os.environ["webdriver.chrome.driver"] = chromedriver
prefs = {"download.default_directory": 'U:\\'}
options.add_experimental_option('prefs', prefs)
options.add_experimental_option('useAutomationExtension', False)
options.add_argument("-incognito")
browser = webdriver.Chrome(chromedriver,options=options)

#url = "http://lkwa12:8002/epms/html/system_mgnt/login.jsp?parea=&site="
url ="http://au3hr8.corpnet.auo.com/eOffering/HRCwebform/HRChange/Query.aspx"
#url ="http://au3ws2.corpnet.auo.com/CAP20/Login.aspx?ReturnUrl=http%3a%2f%2fau3hr8.corpnet.auo.com%2feOffering%2fHRCwebform%2fHRChange%2fQuery.aspx&AppPath=http%3a%2f%2fau3hr8.corpnet.auo.com%2feOffering&r=1"

browser.get(url)

browser.find_element_by_xpath('//*[@id="ctl00_ContentPlaceHolder1_txtUserName"]').send_keys('0525365')
browser.find_element_by_xpath('//*[@id="ctl00_ContentPlaceHolder1_txtPassword"]').send_keys('zxcv456+')
browser.find_element_by_xpath('//*[@id="ctl00_ContentPlaceHolder1_btnLogin"]').click()
browser.find_element_by_xpath('//*[@id="ctl00_cphScript___List1_Panel1"]/table/tbody/tr[6]/td[4]/img[1]').click()
table=browser.find_element_by_xpath('//*[@id="ui-datepicker-div"]/table')
trlist=table.find_elements_by_tag_name('tr')

for row in trlist:
    tdlist=row.find_elements_by_tag_name('td')
    for col in tdlist:
        if col.text=="1":
            col.click()
            break
browser.find_element_by_xpath('//*[@id="ctl00_cphScript___List1_Panel1"]/table/tbody/tr[6]/td[4]/img[2]').click()
table=browser.find_element_by_xpath('//*[@id="ui-datepicker-div"]/table')
trlist=table.find_elements_by_tag_name('tr')
for row in trlist:
    tdlist=row.find_elements_by_tag_name('td')
    for col in tdlist:
        if col.text[0]=="3":
            temp=col
        else:
            continue
temp.click()
browser.find_element_by_xpath('//*[@id="ctl00_cphScript___List1_btnQuery"]').click()
try:
    browser.find_element_by_xpath('//*[@id="ctl00_cphScript___List1_gv_ctl13_Pager1_ddlPageSize"]/option[7]').click()
except:
    pass
try:
    cnt=0
    column=[]
    data=[]
    time.sleep(5)
    tab=browser.find_element_by_xpath('//*[@id="ctl00_cphScript___List1_gv"]')
    rlist=tab.find_elements_by_tag_name('tr')
    for row in rlist:
        if cnt==0:
            dlist=row.find_elements_by_tag_name('th')
        else:
            dlist=row.find_elements_by_tag_name('td')
        temp=[]
        for col in dlist:
            if cnt==0:
                column.append(col.text)
            else:
                temp.append(col.text)
        if cnt>0:
            data.append(temp)
        cnt=cnt+1
    df=pd.DataFrame(data,columns=column)
    if os.path.exists("TESTTTTTT.xlsx"):  
        os.remove("app.cpp")
    print("The file has been deleted successfully")
      

    # df.to_excel('U:\\資料\\python\\爬蟲問卷\\TESTTTTTT.xlsx')
except:
    pass

browser.close()
browser.quit()
 # # ### 讀取 Excel dateframe 整理 ------------------------------------------#!

# print(df)
# df = pd.read_excel(r'U:\資料\python\爬蟲問卷\TESTTTTTT.xlsx',usecols= [8,10,11,12,13,14,17,18,20,21] ,encoding='utf-8') 
# print(df)
df = df[(df['現任部門'] == df['異動後部門']) ==False]
# print(df)

df=df.loc[:,['填表日期','中文姓名','異動人員','異動種類','現任部門','異動後部門','現任職務','異動後職務','預計生效日','實際生效日']]

df.columns=['filling_date','worker_name','worker_id','type_of_change','now_dept','after_dept','now_job','after_job','Expect_effective_date','Actual_Effective_Date']

today = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

df['create_time'] =today
# ## 工號補0

# df['worker_id'] = df['worker_id'].apply(lambda x : '{:0>7d}'.format(x))

# print(df)
# db = pymysql.connect(host='vm02mfg', port=3306, user='admin', passwd='Vm02+1234', db='m02db', charset='utf8')
# cursor() 
# cursor = db.cursor()

engine = create_engine('mysql+pymysql://admin:Vm02+1234@vm02mfg/m02db?charset=utf8')
for i in range(len(df)):
    try:
        df.iloc[i:i+1].to_sql('h_peo_transpose', engine,if_exists='append',index=False) 
        print("上傳成功")  
    except :
        pass
