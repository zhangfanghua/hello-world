# -*- coding: UTF-8 -*-
from selenium import webdriver#selenium 為爬蟲的核心 用來啟動瀏覽器
from selenium.webdriver.common.keys import Keys #模擬鍵盤輸入的插件
from bs4 import BeautifulSoup#使用BeautifulSoup來解析網頁
from time import sleep #sleep為讓程式停止的意思 通常都是用在點擊後網頁會lag 就讓程式先停止稍後在做
import time, datetime #時間的插件
import numpy as np#資料的事前處理，多重維度的陣列
import pandas as pd#資料的事前處理，如資料補值，空值去除或取代等
import csv #為處理CSV的插件
import pymysql
from sqlalchemy import create_engine
import os #處理像是 檔案重新命名、移動、刪除......
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support.ui import Select


options = webdriver.ChromeOptions()
options.add_argument("--disable-notifications")
options.add_experimental_option('useAutomationExtension', False)
chromedriver = r"\\vm02mfg\e$\VM02M0\資訊共享\Chromedriver\V100\chromedriver.exe"
os.environ["webdriver.chrome.driver"] = chromedriver
prefs = {"download.default_directory": 'U:\\'}
options.add_experimental_option('prefs', prefs)
options.add_experimental_option('useAutomationExtension', False)
options.add_argument("-incognito")#無痕模式
options.add_argument('ignore-certificate-errors')
# options.add_argument("-headless")#無頭騎士模式
browser = webdriver.Chrome(chromedriver,options=options)
#開啟網頁
url ="https://login.corpnet.auo.com/Login.aspx?ReturnUrl=http%3a%2f%2fauohqhrmap02.corpnet.auo.com%2fPTMS%2fWebForms%2fDefault.aspx&AppPath=http%3a%2f%2fauohqhrmap02.corpnet.auo.com%2fPTMS"
browser.get(url)
time.sleep(3)
#登入
browser.find_element_by_xpath('//*[@id="ctl00_ContentPlaceHolder1_txtUserName"]').send_keys('0525365')
browser.find_element_by_xpath('//*[@id="ctl00_ContentPlaceHolder1_txtPassword"]').send_keys('zxcv456+')
browser.find_element_by_xpath('//*[@id="ctl00_ContentPlaceHolder1_btnLogin"]').click()
time.sleep(2)
#點選查詢
browser.find_element_by_xpath('//*[@id="ctl00_accordionMenu"]/div[9]/div').click()
time.sleep(2)
#點選個人假勤資料查詢
browser.find_element_by_xpath('//*[@id="ctl00_ctl17_rptItem_ctl00_hlkItem"]').click()
time.sleep(2)
#定位警告框
alert=browser.switch_to.alert
alert.accept()
time.sleep(3)
try:
        alert.accept()
        time.sleep(3)
except:
        alert.accept()
        time.sleep(3)
#清除textbox內容
browser.find_element_by_xpath('//*[@id="ctl00_contentBody_txtEmpNo"]').clear()
time.sleep(1)
#點選下拉式選單 選區 班別異動
Select=Select(browser.find_element_by_id('ctl00_contentBody_ddlWorkedOption'))
Select.select_by_index(6)
time.sleep(1)

try:
        alert.accept()
        time.sleep(1)
except:
        alert.accept()
        time.sleep(1)
#選擇起始日 一週爬一次
today = datetime.date.today().strftime("%Y-%m-%d")
week_ago =(datetime.date.today()- datetime.timedelta(days=7)).strftime("%Y-%m-%d")

browser.find_element_by_xpath('//*[@id="ctl00_contentBody_startFromDate"]').clear()
time.sleep(1)
browser.find_element_by_xpath('//*[@id="ctl00_contentBody_startFromDate"]').send_keys(week_ago)
time.sleep(1)
browser.find_element_by_xpath('//*[@id="ctl00_contentBody_startEndDate"]').clear()
time.sleep(1)
browser.find_element_by_xpath('//*[@id="ctl00_contentBody_startEndDate"]').send_keys(today)
time.sleep(4)
#表名會根據下載的日期
download_date =str(time.localtime(time.time()).tm_year)+str(time.localtime(time.time()).tm_mon)+str(time.localtime(time.time()).tm_mday)
table_name=download_date+"QueryFormsData.xls"
if os.path.exists("U:\\"+table_name): ##如果路徑檔案存在
 
        os.remove("U:\\"+table_name)##刪除路徑檔案
else:
          pass

browser.find_element_by_xpath('//*[@id="ctl00_contentBody_btnExport"]').click()
time.sleep(4)
browser.close()
browser.quit()
 # # ### 讀取 Excel dateframe 整理 ------------------------------------------#!



df = pd.read_excel('U:\\'+table_name,usecols= [3,4,5,6,7,8,9] ,encoding='utf-8') 

df.columns=['workid','worknwme','dept','change_shift','effective_date','reason','reason_remark']
today = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

df['update_time'] =today

## 工號補0
df['workid'] = df['workid'].astype('str') 
df['workid'] =df['workid'].str.zfill(7)

engine = create_engine('mysql+pymysql://admin:Vm02+1234@vm02mfg/m02db?charset=utf8')
for i in range(len(df)):
    try:
        df.iloc[i:i+1].to_sql('h_peo_shift_change', engine,if_exists='append',index=False) 
        
    except :
        pass
print("上傳成功") 

