# -*- coding: UTF-8 -*-
import pandas as pd
import numpy as np
import sqlalchemy 
from sqlalchemy import create_engine
from win32com.client.gencache import EnsureDispatch as Dispatch
from datetime import datetime, timedelta,date
import os


outlook=Dispatch('Outlook.Application').GetNamespace('MAPI')
outlook_ap=Dispatch('Outlook.Application')
Accounts = outlook.Folders

#mysql Link
username='admin'
code='Vm02+1234'
host='vm02mfg'
port='3306'
database='HR'

engine=create_engine("mysql+pymysql://{}:{}@{}/{}".format(username, code, host+':'+port, database))
mail=Accounts.Item("202204").Folders.Item("收件匣").Folders.Item("m02").Folders.Item("m1")  # mail 資料夾
path=r"U:\資料\python\hr"
try:
    os.remove(os.path.join(path, "LK宿舍測試資料.xlsx"))
except:
    pass
for each_mail in mail.Items:
    if('宿舍報表討論' in  each_mail.Subject):
        for attachment in each_mail.Attachments:
            attachment.SaveAsFile(os.path.join(path, "LK宿舍測試資料.xlsx"))
sheet = pd.ExcelFile(os.path.join(path, "LK宿舍測試資料.xlsx")) # read sheet_name
data = pd.read_excel(os.path.join(path, "LK宿舍測試資料.xlsx"), sheet_name=None) # read excel file
con = engine.connect()
dnow=datetime.now().strftime("%Y-%m-%d 00:00:00")
for s_name in sheet.sheet_names:
    #print(s_name)
    if '確診框列表' in s_name:
        cf=data.get(s_name)
        cf.columns=['workID','workName','匡列原因類別','篩檢結果','start_time','end_time','隔離房','remark']
        cf.to_sql('h_isolation_list',con=con, if_exists='append', index=False )
                
        with engine.begin() as cn:
            sql = """INSERT ignore INTO r_isolation_list
                    SELECT workID ,workName,end_time
                    FROM h_isolation_list
                    WHERE  end_time >=   """
            sql+="'"+dnow+"'"
            cn.execute(sql)
            pass
    elif '房間異動表' in s_name:
        cf=data.get(s_name)
        cf.to_sql('h_room_change',con=con, if_exists='append', index=False )
        with engine.begin() as cn:
            sql = """delete   from r_dorm_room  where WorkID  in (
                    SELECT 工號
                    FROM h_room_change
                    WHERE  動作='退') """
            sql2="""INSERT ignore INTO r_dorm_room
                    SELECT 工號 ,WorkName ,房號,日期
                    FROM h_room_change left join tableau.h_104 
                    on 工號 =WorkID 
                    WHERE  動作 ='入' """
            sql3="""UPDATE r_dorm_room
         INNER JOIN h_room_change ON WorkID = 工號 
SET Room= 房號 ,lm_time =日期 where   動作 ='換' """

           
            cn.execute(sql)
            cn.execute(sql2)
            cn.execute(sql3)
        pass
    elif '度假外宿申請' in s_name:
        cf=data.get(s_name)
        cf.to_sql('h_vacation_apply',con=con, if_exists='replace', index=False )
        pass
    elif '外出紀錄' in s_name:
        cf=data.get(s_name)
        cf.to_sql('h_out_record',con=con, if_exists='replace', index=False )
        pass
con.close()
   
               