# -*- coding: UTF-8 -*-
from itertools import count
from select import select
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
import time
from selenium.webdriver.support import expected_conditions as EC
# send_keys模擬鍵盤輸入
from selenium.webdriver.common.keys import Keys 
# for Web page load 
from selenium.webdriver.support.ui import WebDriverWait
# for dropdownlist
from selenium.webdriver.support.ui import Select
# for dataframe
import pandas as pd
from datetime import datetime
from sqlalchemy import create_engine
import re
#import number_of_use
import os 


# # ### 讀取 Excel dateframe 整理 ------------------------------------------#!


df = pd.read_excel(r'\\auo\gfs\LK000\M02_MFG\M02M0\MM02M2\RECORDS_APS\month.xlsx',usecols= [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20] ,encoding='utf-8') 


#df=df.loc['FAB','PHASE','MONTH','ORG_ID','ORG_CNAME','EMP_NO','CLASS_ID','KIND_CODE','EMP_KIND','RTIME應出勤工時','FOTIME固定加班','HTIME請假時數','HTIME_1無薪假時數','OTIME加班時數','OTIME1申請補休','OTIME2申請加班','PTIME實際工作時數','今年度剩餘','去年度剩餘','JOB_IDL']

df.columns=['FAB','PHASE','MONTH_','DEPT_ID','DEPT','WORKID','SHIFT','KIND_CODE','EMP_KIND','rtime_working_hours','Fixed_overtime','dayoff_time','unpaid_leave_time','overtime','Apply_compensatory_time','Apply_overtime','Actual_working_hours','remainder_year','Remainder_lastyear','JOB_IDL']
today = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

df['update_time'] =today
# print(df)
## 工號補0
df['WORKID'] = df['WORKID'].astype('str') 
df['WORKID'] =df['WORKID'].str.zfill(7)
#df['WORKID'] =  type(df['WORKID']).apply(lambda x : '{:0>7d}'.format(x))

engine = create_engine('mysql+pymysql://admin:Vm02+1234@vm02mfg/m02_mfg?charset=utf8')
for i in range(len(df)):
    try:
        df.iloc[i:i+1].to_sql('h_peo_m02aps_csv', engine,if_exists='append',index=False) 
        
    except :
        pass
print("上傳成功") 
